import sqlalchemy.ext.declarative


ModelBase = sqlalchemy.ext.declarative.declarative_base()
